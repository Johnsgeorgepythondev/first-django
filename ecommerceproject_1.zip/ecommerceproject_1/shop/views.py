from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404

from .models import Category, Product


def home(request, slug_c=None):
    page_c = None
    if slug_c!=None:
        page_c = get_object_or_404(Category, slug=slug_c)
        products = Product.objects.all().filter(category=page_c, available=True)
    else:
        products = Product.objects.all().filter(available=True)

    return render(request, 'home.html', {'category': page_c, 'products': products})


# def home(request):
# return render(request, 'home.html')


def contact(request, ):
    return django.shortcuts.render(request, 'base.html')

# Create your views here.
